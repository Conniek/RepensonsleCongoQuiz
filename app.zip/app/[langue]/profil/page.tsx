import { notFound } from "next/navigation";
import { dictionnaire, estLangue } from "@/lib/i18n";
import ProfilClient from "./profil-client";

export async function generateMetadata({ params }: { params: Promise<{ langue: string }> }) {
  const { langue } = await params;
  if (!estLangue(langue)) return {};
  return { title: dictionnaire(langue).pageProfil.titre };
}

export default async function PageProfil({ params }: { params: Promise<{ langue: string }> }) {
  const { langue } = await params;
  if (!estLangue(langue)) notFound();
  return <ProfilClient langue={langue} />;
}
