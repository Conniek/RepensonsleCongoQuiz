# Modèle multilingue — français et anglais

Deux dettes réglées d'un coup : l'identité des catégories séparée de leur
présentation, et le modèle préparé pour deux langues.

## Avant tout : sauvegarder

C'est la première migration qui réécrit des données existantes. Elle touche
`question`, `partie` et `maitrise`.

```bash
pg_dump "$DB_URL" > sauvegarde-avant-i18n.sql
```

Ou depuis la console : Database → Backups.

## Installation

### 1. Appliquer les trois migrations, dans l'ordre

```bash
psql "$DB_URL" -v ON_ERROR_STOP=1 -f supabase/migrations/20260919001100_modele_multilingue.sql
psql "$DB_URL" -v ON_ERROR_STOP=1 -f supabase/migrations/20260919001200_vues_et_fonctions_i18n.sql
psql "$DB_URL" -v ON_ERROR_STOP=1 -f supabase/migrations/20260919001300_progression_i18n.sql
```

La première se termine par un contrôle de cohérence : si le nombre de textes
français ne correspond pas au nombre de questions, elle échoue et annule tout.
Un `NOTICE` confirme la reprise.

### 2. Déplacer les fichiers de l'application

L'arborescence change : **tout passe sous `app/[langue]/`**, et
`app/layout.tsx` disparaît. Quand toutes les routes vivent sous un segment de
langue, c'est `app/[langue]/layout.tsx` qui porte `<html>` et `<body>` — c'est
ainsi que l'attribut `lang` devient enfin dynamique.

```bash
# Supprimer l'ancienne arborescence
rm -rf app/layout.tsx app/page.tsx app/progression.tsx \
       app/categorie app/partie app/resultat app/profil app/compte

# Décompresser la nouvelle
unzip -o rlc-i18n.zip
cp -r rlc-i18n/app rlc-i18n/lib rlc-i18n/middleware.ts .
cp rlc-i18n/supabase/migrations/*.sql supabase/migrations/
rm -rf rlc-i18n
```

Il doit rester `app/lecture.css` à la racine de `app/`, importé depuis
`app/[langue]/layout.tsx`.

### 3. Vérifier

```bash
npm run dev
```

`localhost:3000` doit rediriger vers `/fr`. `/en` doit s'afficher en anglais,
avec zéro catégorie jouable et le message qui l'explique.

## Le modèle

**Ce qui ne dépend pas de la langue** reste sur `question` : catégorie,
difficulté, image, tags, compteurs, et l'**index de la bonne réponse**.

**Ce qui en dépend** vit dans `question_texte`, une ligne par langue :
énoncé, propositions, sous-catégorie, explication, source, texte alternatif.

Même séparation pour les catégories : `categorie` porte un code stable
(`geographie-26-provinces`), `categorie_texte` porte le libellé et le slug par
langue.

### Pourquoi les compteurs restent sur la question

`vues` et `reussites` ne sont pas dupliqués par langue. La même question a le
même taux de réussite en français et en anglais : si chaque traduction avait
ses propres compteurs, la recalibration de la difficulté travaillerait sur des
échantillons divisés et perdrait son sens.

### Le piège de l'index partagé

`bonne_reponse` est un index dans le tableau des propositions, et il est
**commun à toutes les langues**. Un traducteur qui réordonne les propositions
casserait la justesse partout à la fois, sans qu'aucune contrainte ne le
signale.

Conséquence pour le back-office : les propositions s'éditent comme une **liste
ordonnée figée**, position par position, avec la bonne réponse affichée en
lecture seule. C'est une contrainte d'interface, pas de schéma, et elle est
critique.

### Badges et rangs en JSON

Huit et cinq lignes, éditées d'un bloc, jamais filtrées par langue : le JSON
est ici le bon compromis. La fonction `texte_i18n()` replie sur le français si
la traduction manque — un badge sans libellé anglais reste affichable.

## Le comportement de l'anglais au lancement

Zéro question traduite, donc :

- l'accueil anglais n'affiche **aucune catégorie** et l'explique ;
- une catégorie n'apparaît qu'au-delà de 7 questions traduites ;
- `composer_deck` refuse une catégorie insuffisamment traduite, avec un code
  d'erreur distinct de celui d'un niveau verrouillé.

On ne sert jamais une question dans une autre langue que celle demandée : une
partie moitié française moitié anglaise serait pire qu'une catégorie absente.

Pour suivre l'avancement :

```sql
select * from completude_traduction where langue = 'en' order by pourcentage desc;
```

## Vérifications après migration

```sql
-- Reprise des données
select count(*) from question;                          -- 1445
select count(*) from question_texte where langue='fr';  -- 1445
select count(*) from categorie;                         -- 12
select count(*) from categorie_texte;                   -- 12

-- Aucune partie orpheline
select count(*) from partie p
  left join categorie c on c.id = p.categorie_id
 where p.categorie_id is not null and c.id is null;     -- 0

-- La maîtrise a suivi
select categorie_id, niveau, etoiles from maitrise limit 5;

-- La sécurité tient toujours
set role anon;
select * from question limit 1;             -- doit ÉCHOUER
select * from question_texte limit 1;       -- doit ÉCHOUER
select * from question_publique limit 1;    -- doit RÉUSSIR, sans bonne_reponse
reset role;
```

Puis dans l'application : une partie complète en français, avec les étoiles et
l'expérience qui s'accumulent comme avant. Et `/en`, qui doit s'afficher
proprement en annonçant qu'aucune catégorie n'est disponible.

## Ce que ça ouvre pour la suite

Le back-office sera nativement multilingue : une question s'édite dans sa
langue, avec l'état de traduction visible, et l'écran de complétude dira quand
l'anglais peut s'ouvrir.

Et la traduction des 1 445 questions devient un travail éditorial mesurable,
catégorie par catégorie, au lieu d'un chantier flou.
